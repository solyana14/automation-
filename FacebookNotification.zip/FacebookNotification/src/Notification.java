import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class Notification {
    WebDriver driver = new ChromeDriver();

    public void getNotification(){
        String Email = "email" ;
        String Pass ="password";
        driver.navigate().to("http://www.facebook.com/"); //go to facebook.com

        WebElement email = driver.findElement(By.id("email"));
        WebElement password = driver.findElement(By.id("pass"));
        WebElement loginButton = driver.findElement(By.id("loginbutton"));

        email.sendKeys(Email);
        password.sendKeys(Pass);

        loginButton.click();

        driver.navigate().to("http://www.facebook.com/");
        WebElement notificationCount = driver.findElement(By.id("notificationsCountValue"));
        System.out.println("You have"+ notificationCount.getText()+" notifications");

        driver.close();
    }
    public static void main(String [] args){
        Notification facebook = new Notification();
        facebook.getNotification();

    }
}
